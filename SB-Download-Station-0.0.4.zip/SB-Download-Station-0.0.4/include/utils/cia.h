#pragma once

#include "common.hpp"

Result installCia(const char * ciaPath);
