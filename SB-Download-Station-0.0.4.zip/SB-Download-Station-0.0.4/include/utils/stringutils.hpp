#pragma once

#include "common.hpp"

bool matchPattern(std::string pattern, std::string tested);
