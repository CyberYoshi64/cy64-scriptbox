#ifndef MSG_HPP
#define MSG_HPP

#include <string>

namespace Msg
{
	void DisplayMsg(std::string text);
	bool promptMsg(std::string promptMsg);
}

#endif