#include "init.hpp"

int main(){
	Init::MainLoop();
}
