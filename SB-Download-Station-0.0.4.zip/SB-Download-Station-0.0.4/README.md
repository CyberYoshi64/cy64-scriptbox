# SmileBASIC Download Station

See [the SmileBASIC Source thread](http://smilebasicsource.com/forum?fpid=31784#post_31784)
for further information.

## Credits

* [the_squat1115 (SBS)](http://smilebasicsource.com/user/the_squat1115) - Inital idea
* [devkitPro](https://github.com/devkitPro): The use of devkitPro, devkitARM, libctru and citro2d.
* [Epicpkmn11](https://github.com/Epicpkmn11): Initial CIA installation code (based on [MultiUpdater](https://github.com/LiquidFenrir/MultiUpdater))
* [Universal-Team](https://github.com/Universal-Team): CIA installation code improvements.
* [FlagBrew](https://github.com/FlagBrew/Checkpoint) - Thread code
