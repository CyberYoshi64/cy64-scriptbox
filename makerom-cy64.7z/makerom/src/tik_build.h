#pragma once
#include "tik.h"

// Prototypes
int BuildTicket(cia_settings *ciaset);