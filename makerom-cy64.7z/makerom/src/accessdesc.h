#pragma once

int set_AccessDesc(exheader_settings *exhdrset);