#pragma once

int PrepareImportRomFsBinaryFromFile(ncch_settings *ncchset, romfs_buildctx *ctx);
int ImportRomFsBinaryFromFile(romfs_buildctx *ctx);