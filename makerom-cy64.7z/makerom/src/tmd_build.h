#pragma once
#include "tmd.h"

// Prototypes
u32 PredictTMDSize(u16 ContentCount);
int BuildTMD(cia_settings *ciaset);
