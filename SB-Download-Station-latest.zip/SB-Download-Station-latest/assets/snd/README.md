# Application sounds

This folder contains all sound effects that the application uses.

## Build target

File: `romfs/cy-ptchj.cycwar`

Format definition: [CYCWAR](https://github.com/CyberYoshi64/SB-Download-Station/blob/main/_git-assets/zfmt-cycwar.md)

## Descriptions

* `COMMON_ACTION_ERR` - Notification/Dialog sound for errors
* `COMMON_ACTION_MENU` - General notification sound
* `COMMON_ACTION_MOVE` - Moving in menu layouts or uncollapse entry
* `COMMON_ACTION_STOP` - Collapse entry
* `COMMON_ACTION_WAIT.r` - Menu delays
* `COMMON_ACTION_WARN` - Notification/Dialog sound for warnings
* `COMMON_ACTION_WRONG` - Cursor bouncing in menu
* `COMMON_BGM0_2ch.r` - Menu music
* `COMMON_MENU_BACK` - Back button
* `COMMON_MENU_OK` - OK button
* `COMMON_MENU_TAP` - Touch/Navigate
* `DIALOG_WAIT.r` - Dialog busy symbol
