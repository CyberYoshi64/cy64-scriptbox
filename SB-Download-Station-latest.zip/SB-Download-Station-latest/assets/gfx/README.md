# App graphics

This folder contains the graphics used in the application.

## Build target

File: `romfs/gfx/*.t3x`, `assets/gfx/*.t3x.png`
File format: [T3X (Tex3DS)](https://github.com/devkitPro/tex3ds)

## Descriptions

* `appdlg` - Dialog graphics (fmt: A4)
* `button` - Button graphics (fmt: ETC1A4)
* `common` - Various menu graphics (FMT: ETC1A4)
* `cy64` - Shameless plug (fmt: ETC1A4)
* `hud` - HUD and notification graphics (fmt: RGAB8)
* `menugfx` - Menu buttons (fmt: RGBA8)
* `scrbg` - Background images (fmt: ETC1)
