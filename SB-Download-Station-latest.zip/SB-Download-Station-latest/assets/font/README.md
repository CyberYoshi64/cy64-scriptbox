# Application font

This folder contains the font that the application uses.

Font map:
![Oh! The font map was not found... Is this folder containing 0.map.png by chance?](https://github.com/CyberYoshi64/SB-Download-Station/blob/main/romfs/font/0.map.png?raw=true)

## Font sources

* Rodin NTLG Pro DB (Adobe archive)
* Material Icons (Google)
* Nintendo Ext-003 (3DS/WiiU/Switch PUA)
* SmileBASIC 3 – PUA
* Miiverse Icons (Miiverse archive)

## Font properties when built

* Point size: **18.165**
* Characters defined: **1535**
