#ifndef MATHLOGIC_HPP
#define MATHLOGIC_HPP

#include <3ds.h>
#define clamp(x,min,max) C2D_Clamp(x,min,max)

float math_abs(float val);
float math_pow2(float val);
int percval(int at0, int at100, float perc);
float percvalf(float at0, float at100, float perc);
float _1ddist(float x0,float x1);
float _2ddist(float x0,float y0,float x1, float y1);
float mixNum(float num1, float num2, float ratio);
bool TouchedHitbox(bool tt, u32 tx, u32 ty, u32 x, u32 y, u32 w, u32 h);

#endif