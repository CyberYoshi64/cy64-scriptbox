#ifndef META_HPP
#define META_HPP

#include "common.hpp"

#define META_FLAG_CANCEL	BIT(0)
#define META_FLAG_ALPHA		BIT(1)
#define META_FLAG_BETA		BIT(2)
#define META_FLAG_DEV		BIT(3)
#define META_FLAG_GAME		BIT(4)
#define META_FLAG_TOOL		BIT(5)
#define META_FLAG_UI		BIT(6)

namespace Meta {
	struct Title {
		u32 version;
		u32 blksz;
		u16 filecnt;
		u16 flags;
		std::string prjname;
		std::string prjfolder;
		std::string desc;
		std::string maker;
	};
	Result init(void);
	void prepareArrays(std::string fc);
	void exit(void);
}

#endif
