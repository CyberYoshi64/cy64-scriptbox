#ifndef SPRITE_HPP
#define SPRITE_HPP

#include "common.hpp"

#define SPRITEFRMWRK_SIZE	512
#define SPRITEFRMWRK_SCR_TOP	0
#define SPRITEFRMWRK_SCR_BOTTOM	1

#define SPRITEFRMWRK_TEXTSZ	256
#define SPRITEFRMWRK_TXTW	2/3.f
#define SPRITEFRMWRK_TXTH	2/3.f

#define SPRITEFRMWRK_CNV_RAD2DEG 360 / (NUMBER_PI*2)
#define SPRITEFRMWRK_CNV_DEG2RAD (NUMBER_PI * 2) / 360

#define Sprite_LinkMask_Pos			BIT(0)
#define Sprite_LinkMask_Rotation	BIT(1)
#define Sprite_LinkMask_Scale		BIT(2)
#define Sprite_LinkMask_Tint		BIT(3)
#define Sprite_LinkMask_FollowDeath	BIT(4)

typedef struct {
	bool active, shown, screen;
	u8 textype;
	C2D_Text text; C2D_TextBuf tbuf;
	C2D_SpriteSheet sheet; size_t index;
	u32 texw, texh;
	struct {
		float x, y, z;
	} pos;
	struct {
		float x, y;
	} center;
	struct {
		float x, y;
	} scale;
	float rot;
	char name[33];//Size 32c + NUL char
	C2D_ImageTint tint;
	u16 linkParent; u8 linkMask;
	float floats[16]; int ints[32];
} Sprite;

namespace SpriteFrmwrk {
	void init(void);
	void exit(void);
	void render(bool scr);
	void clearAll(void);
	void clearRange(u16 first, u16 last);
	void setSprite(u16 index, C2D_SpriteSheet sheet, size_t sheetidx, bool screen);
	void setSprite(u16 index, const char* text, bool screen);
	u16 setSprRemote(u16 firstid, C2D_SpriteSheet sheet, size_t sheetidx, bool screen);
	u16 setSprRemote(u16 firstid, const char* text, bool screen);
	void setSprGfx(u16 index, C2D_SpriteSheet sheet, size_t sheetidx);
	void setSprTxt(u16 index, const char* text);
	void setSprScr(u16 index, bool screen);
	void setSprOff(u16 index, float x, float y);
	void setSprHome(u16 index, float x, float y);
	void setSprDepth(u16 index, float z);
	void setSprRot(u16 index, float r);
	void setSprScale(u16 index, float sx, float sy);
	void setSprTint(u16 index, C2D_ImageTint tint);
	void setSprName(u16 index, const char* name);
	void setSprLink(u16 index, u16 father, u8 mask);
	void setSprVisible(u16 index, bool show);
	void setSprFloat(u16 index, u8 var, float value);
	void setSprInt(u16 index, u8 var, int value);
	void addSprOff(u16 index, float x, float y);
	void addSprRot(u16 index, float r);
	void getSprGfx(u16 index, C2D_SpriteSheet sheet, size_t* sheetidx);
	void getSprTxt(u16 index, char* text);
	void getSprTexSize(u16 index, u32* w, u32* h);
	bool getSprScr(u16 index);
	void getSprOff(u16 index, float* x, float* y);
	void getSprHome(u16 index, float* x, float* y);
	float getSprDepth(u16 index);
	float getSprRot(u16 index);
	void getSprScale(u16 index, float* sx, float* sy);
	C2D_ImageTint* getSprTint(u16 index);
	char* getSprName(u16 index);
	void getSprLink(u16 index, u16* father, u8* mask);
	bool getSprVisible(u16 index);
	float getSprFloat(u16 index, u8 var);
	int getSprInt(u16 index, u8 var);
	void clearSprite(u16 index);
}
#endif