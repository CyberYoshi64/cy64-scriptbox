#ifndef SCREEN_TOP_HPP
#define SCREEN_TOP_HPP

#define SCRTOPNOTIF_SFX_NONE	0
#define SCRTOPNOTIF_SFX_ERROR	1
#define SCRTOPNOTIF_SFX_WARNING	2
#define SCRTOPNOTIF_SFX_MENU	3
#define SCRTOPNOTIF_SFX_WRONG	4

#include "common.hpp"

extern bool drawingScreen;
extern bool stopScreenUpdate;
extern bool dspfirmfound;
extern char errorstr[];
extern int errorcode;
extern int touchpt, touchpx, touchpy;
extern int touchot, touchox, touchoy;
extern int maincnt;
extern float millisec;
extern std::string keyboardIn;
extern C2D_TextBuf sizeBuf;
extern C2D_Font systemFont;
extern u8 CFGLang;
extern bool exiting;

namespace Display {
	void Render(void);
}

#endif
