#ifndef CYCWAR_HPP
#define CYCWAR_HPP

#include "sound.hpp"

typedef struct {
	Sound* snd;
	char name[64];
	size_t fsz;
	char flg;
} CY_CWAR_SE;

namespace CY_CWAR {
	void Free();
	int LoadCYCWAR(const char* fname);
	size_t GetID(const char* name);
	Sound* GetSfx(const char* name);
	void Play(const char* name);
	void PlayID(size_t idx);
	void Stop(const char* name);
	void StopID(size_t idx);
	void SetVolume(const char* name, float vol);
	void SetVolumeWithID(size_t idx, float vol);
	void SetPitch(const char* name, float pth);
	void SetPitchWithID(size_t idx, float pth);
	void FadeVolume(const char* name, float vol, int frm);
	void FadeVolumeWithID(size_t idx, float vol, int frm);
	void FadePitch(const char* name, float pth, int frm);
	void FadePitchWithID(size_t idx, float pth, int frm);
	void Tick();
}

#endif