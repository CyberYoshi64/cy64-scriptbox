#ifndef MEMCPYCTR_H
#define MEMCPYCTR_H
#include <3ds/types.h>
void* memcpy_ctr(void* dst, void* src, u32 size);
#endif