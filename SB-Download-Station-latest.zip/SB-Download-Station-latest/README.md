# ![SmileBASIC Project Manager](https://github.com/CyberYoshi64/SB-Download-Station/blob/main/_git-assets/appicon-w-name.png?raw=true)

**I haven't got it to work for v0.1.0. The below text applies to 0.0.4.**

This tools allows you to manage your SmileBASIC projects and download more from a seperate repository.

## Credits

* [PabloMK7](https://github.com/mariohackandglitch): libcwav and libncsnd
* [the_squat1115 (SBS)](http://old.smilebasicsource.com/user/the_squat1115) - Initial idea
* [devkitPro](https://github.com/devkitPro): The use of devkitPro, devkitARM, libctru and citro2d.
* [Universal-Team](https://github.com/Universal-Team): CIA installation code
* [FlagBrew](https://github.com/FlagBrew/Checkpoint) - Thread code
