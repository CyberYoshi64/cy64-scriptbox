#!/bin/bash

cd assets/snd
for i in *.wav; do
j=$(echo $(head -c -5 <(echo $i)))
if [ $(tail -c 3 <(echo $j)) = ".r" ]; then
	k=$(echo $(head -c -3 <(echo $j)))
	cwavtool -i $j.wav -o $k.bcwav -e dspadpcm -ls 0 -le end
else
	cwavtool -i $j.wav -o $j.bcwav -e dspadpcm
fi
done
cd ../..
