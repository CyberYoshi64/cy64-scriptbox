#!/bin/sh

clear

echo "——— Preparing…"
rm -rf build romfs/gfx > /dev/null
rm -rf assets/gfx/*.t3x.png romfs/*.cycwar > /dev/null
make clean > /dev/null

mkdir build
if ! bannertool makebanner \
-i app/banner.png \
-a app/audio.wav \
-o build/banner.bnr; then #\
	echo "banner.bnr couldn't be created for CIA."
	echo "Refusing to continue."
	exit 1
fi
#\
#-eei app/banner/eu-en.png \
#-efi app/banner/eu-fr.png \
#-egi app/banner/eu-de.png \
#-eii app/banner/eu-it.png \
#-esi app/banner/eu-es.png \
#-edi app/banner/eu-nl.png \
#-epi app/banner/eu-pt.png \
#-eri app/banner/eu-ru.png \
#-jji app/banner/ja-jp.png \
#-uei app/banner/us-en.png \
#-ufi app/banner/us-fr.png \
#-usi app/banner/us-es.png \
#-upi app/banner/us-pt.png

if ! bannertool makesmdh \
-s "SmileBASIC Project Manager" \
-l "SmileBASIC Project Manager" \
-p "CyberYoshi64" \
-i app/icon.png \
-o build/icon.icn \
\
-js "プチコン３号ダウンロードステーション" \
-jl "プチコン３号ダウンロードステーション" \
-jp "CyberYoshi64" \
\
-gs "SmileBASIC-Download-Station" \
-gl "SmileBASIC-Download-Station" \
-gp "CyberYoshi64" \
\
-r regionfree -f visible,nosavebackups,allow3d; then
	echo "Failed creating icon.icn for CIA."
	echo "Refusing to continue."
	exit 1
fi

if ! bannertool makesmdh \
-s "SmileBASIC Download Station" \
-l "Manage and download SmileBASIC projects" \
-p "CyberYoshi64" \
-i app/icon.png \
-o build/ic.smdh; then
	echo "Faield creating ic.smdh for 3DSX."
	echo "Refusing to continue."
	exit 1
fi

#if ! mkbcfnt -s 20 -o romfs/font/0.bcfnt romfs/font/0.ttf; then
#	echo "Faield creating 0.bcfnt for app."
#	echo "Refusing to continue."
#	exit 1
#fi


./tools/prepwav.sh
./tools/mkcycwar.py assets/snd romfs/cy-ptchj

echo "——— Compiling…"
if make elf 3dsx cia; then
	cd output
	mkdir SDRoot
	mkdir 3ds; mkdir cia
	mkdir 3ds/cy64ptc3hj
	cp cy64ptc3hj.3dsx ../__pending_build.cy64.3dsx
	cp cy64ptc3hj.cia ../__pending_build.cy64.cia
	cp cy64ptc3hj.3dsx 3ds/cy64ptc3hj/cy64ptc3hj.3dsx
	cp ../build/icon.icn 3ds/cy64ptc3hj/cy64ptc3hj.smdh
	cp cy64ptc3hj.cia cia/cy64ptc3hj.cia
	mv 3ds SDRoot/3ds; mv cia SDRoot/cia
	cd ..
	echo ""
	echo "Build was successful!"
	echo ""
	echo "Copy the contents of the output/SDRoot folder to the root of the SD card."
	echo "See the INSTALL.md for installing details."
	exit 0
else
	echo ""
	echo "An error has occured."
	echo "This shouldn't have happened, should it?"
	exit 1
fi
