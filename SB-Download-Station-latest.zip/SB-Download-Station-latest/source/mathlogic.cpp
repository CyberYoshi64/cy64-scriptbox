#include <citro2d.h>
#include "mathlogic.hpp"

float math_abs(float val){
	float res = val;
	if (res<0){res -= val*2;}
	return res;
}
float percvalf(float at0, float at100, float perc){
	return at0*(1-perc)+at100*(perc);
}
int percval(int at0, int at100, float perc){
	return at0*(1-perc)+at100*(perc);
}
float math_pow2(float val){
	return val*val;
}
float _1ddist(float x0,float x1){
	return math_abs(x0-x1);
}
float _2ddist(float x0,float y0,float x1, float y1){
	return std::sqrt(math_pow2(math_abs(x0-x1))+math_pow2(math_abs(y0-y1)));
}

float mixNum(float num1, float num2, float ratio){
	ratio=C2D_Clamp(ratio,0.0f,1.0f);
	if (num1>num2){
		return num1-_1ddist(num1,num2)*ratio;
	} else {
		return num1+_1ddist(num1,num2)*ratio;
	}
}

bool TouchedHitbox(bool tt, u32 tx, u32 ty, u32 x, u32 y, u32 w, u32 h){
	return tt&&(clamp(tx,x,x+w-1)==tx && clamp(ty,y,y+h-1)==ty);
}
