#include "common.hpp"

extern int errorcode;
std::string meta_prjn[256];
std::string meta_title[256];
std::string meta_creator[256];
std::string meta_desc[256];
u32 meta_flags[256];
u32 meta_ver[256];
u32 meta_blksz[256];
u32 meta_total;
char metatemp[4];
Result Meta::init(){ // Initialise arrays
	for (int i=0; i < 256; i++){
		meta_prjn[i].clear();
		meta_title[i].clear();
		meta_creator[i].clear();
		meta_desc[i].clear();
		meta_ver[i]=0;
		meta_blksz[i]=0;
		meta_flags[i]=0;
	}
	meta_total=0;
	return 0;
}

void Meta::prepareArrays(std::string fc){
	int term=0x203a3a;
	bool trimf;
	u8 type=0;
	u16 index=0;
	u32 flgs=0;
	u32 meta_idx;
	std::string cnv2cstr;
	init();
	
	for (meta_idx=0; meta_idx < fc.length()-12; meta_idx+=2){
		if (((fc[meta_idx]<<16)|(fc[meta_idx+2]<<8)|fc[meta_idx+4]) == term){
			switch (type){
				case 0: meta_prjn[index]=cnv2cstr; break;
				case 1: meta_blksz[index] = stoi(cnv2cstr); break;
				case 2: meta_title[index]=cnv2cstr; break;
				case 3: meta_creator[index]=cnv2cstr; break;
				case 4: meta_desc[index]=cnv2cstr; break;
				case 5: meta_ver[index] = stoi(cnv2cstr); break;
				case 6: meta_flags[index] = flgs; break;
			}
			gspWaitForVBlank();
			meta_idx+=8; ++type %= 7; cnv2cstr.clear(); flgs=0;
			if (type==0){index++; meta_idx+=2;}
		}
		if (meta_idx < fc.length()-12 && index < 256){
			sprintf(metatemp,"%lc",(fc[meta_idx] | (fc[meta_idx+1]<<8))); trimf=1;
			if (type==0) trimf=(cnv2cstr.length()<14);
			if (type==2) trimf=(cnv2cstr.length()<128);
			if (type==3) trimf=(cnv2cstr.length()<64);
			if (type==4) trimf=(cnv2cstr.length()<320);
			
			if (trimf){
				cnv2cstr += metatemp;
				if (type==6){
					switch (fc[meta_idx]){
						case 97: flgs |= META_FLAG_ALPHA; break;
						case 98: flgs |= META_FLAG_BETA; break;
						case 99: flgs |= META_FLAG_CANCEL; break;
						case 100: flgs |= META_FLAG_DEV; break;
						case 103: flgs |= META_FLAG_GAME; break;
						case 116: flgs |= META_FLAG_TOOL; break;
						case 117: flgs |= META_FLAG_UI; break;
					}
				}
			}
		}
	}
	meta_total = index;
}

void Meta::exit(){
	// There's nothing on the heap yet, so no cleaning up needed.
}
