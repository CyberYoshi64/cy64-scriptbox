#include "sb3files.hpp"

void SB3File::GetDate(){
	//
}
void SB3File::GetTime(){
	//
}
u8 SB3File::GetFileType(){
	//
}
u8 SB3File::GetSubType(){
	//
}
void SB3File::GetCreator(){
	//
}
void SB3File::GetEditor(){
	//
}