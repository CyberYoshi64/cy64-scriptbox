#include "common.hpp"
#include "main.hpp"
#include "cia.hpp"
#include "keyboard.h"
#include "cy_cwar.hpp"
#include "sound.hpp"
#include "thread.h"
#include <3ds.h>
#include <dirent.h>
#include <unistd.h>

bool drawingScreen = true;
bool stopScreenUpdate = true;
static touchPosition touch;
extern int errorcode;
extern char errorstr[];

Handle FShandle;
FS_Path FSpath;
FS_Archive FSarc;
FS_Archive extarc;

char* string0;
bool dspfirmfound = false;
u8 CFGLang;
u8 consoleModel;
u8 consoleRegion;
Result init_res;
Result appres;
bool isInit = true;
int delay = 0;
bool exiting = false;
bool waiting = false;
C2D_SpriteSheet sprites;

Result Initialize() {
	romfsMountSelf("rom");
	gfxInitDefault();
	C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
	C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
	C2D_Prepare();
	mcuHwcInit();
	Gui::init();
	cfguInit();
	acInit();
	amInit();
	fsInit();
	osSetSpeedupEnable(true);	// Enable speed-up for New 3DS users
	CFGU_GetSystemLanguage(&CFGLang);
	CFGU_SecureInfoGetRegion(&consoleRegion);
	CFGU_GetSystemModel(&consoleModel);
	
 	if (access("sdmc:/3ds/dspfirm.cdc", F_OK ) != -1 ) { // Was DSP firm dumped before?
		ndspInit(); // If so, then initialise the service
		dspfirmfound = true;
	}
	
	u32 extdata_archive_lowpathdata[3] = {1,0x00001a1c,0};
	appres=FSUSER_OpenArchive(&extarc, ARCHIVE_EXTDATA, (FS_Path){PATH_BINARY, 12, &extdata_archive_lowpathdata});
	
	//if (osGetKernelVersion() < SYSTEM_VERSION(2,57,0)){errorcode=99999999; exiting=true;}
	if (CY_CWAR::LoadCYCWAR("rom:/cy-ptchj.cycwar")!=0) errorcode=10000002;
	SpriteFrmwrk::init();
	return 0;
}

int main() {
	// Initialize everything.
	Initialize();
	// Loop as long as the status is not exiting.
	while (aptMainLoop()) {
		hidScanInput();
		u32 hHeld = hidKeysHeld();
		u32 hDown = hidKeysDown();
		hidTouchRead(&touch);
		if (errorcode == 0){
			Gui::ScreenLogic(hDown, hHeld, touch); // Call the logic of the current screen here.
		}
		if (exiting) {
			SpriteFrmwrk::exit();
			CY_CWAR::Free();
			Gui::exit();
			break;
		}
		if (isInit) {
			CY_CWAR::SetPitch("COMMON_BGM0", 1.25);
			CY_CWAR::Play("COMMON_BGM0");
			isInit = false;
		}
		CY_CWAR::Tick();
		Display::Render();
	}
	// Clean up and leave the building
	ndspExit();
	FSUSER_ControlArchive(extarc, ARCHIVE_ACTION_COMMIT_SAVE_DATA, nullptr, 0, nullptr, 0);
	FSUSER_CloseArchive(extarc);
	fsExit();
	amExit();
	acExit();
	cfguExit();
	mcuHwcExit();
	C2D_Fini();
	C3D_Fini();
	gfxExit();
	romfsUnmount("rom");
	return 0;
}
