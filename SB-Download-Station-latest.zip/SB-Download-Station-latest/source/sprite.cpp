#include "sprite.hpp"

static Sprite sprites[SPRITEFRMWRK_SIZE];
char spritefrmwrktmp[256];

void SpriteFrmwrk::init(){
	clearAll();
	for (u16 i=0; i < SPRITEFRMWRK_SIZE; i++)
		sprites[i].tbuf = C2D_TextBufNew(SPRITEFRMWRK_TEXTSZ);
}

void SpriteFrmwrk::exit(){
	for (u16 i=0; i < SPRITEFRMWRK_SIZE; i++)
		if (sprites[i].tbuf) C2D_TextBufDelete(sprites[i].tbuf);
}

void SpriteFrmwrk::render(bool scr){
	C2D_DrawParams drw; u16 lkp; u8 lm; C2D_ImageTint tn;
	float x, y, z, sx, sy, hx, hy, rot; u32 tx, ty;
	C2D_Text ctx;
	for (u16 i=0; i < SPRITEFRMWRK_SIZE; i++) {
		if (!sprites[i].active || !sprites[i].shown || (sprites[i].screen != scr)) continue;
		x=sprites[i].pos.x; y=sprites[i].pos.y; z=sprites[i].pos.z;
		sx=sprites[i].scale.x; sy=sprites[i].scale.y;
		hx=sprites[i].center.x; hy=sprites[i].center.y;
		rot=sprites[i].rot; tx=sprites[i].texw; ty=sprites[i].texh;
		lkp=sprites[i].linkParent; lm=sprites[i].linkMask;
		tn=sprites[i].tint; ctx=sprites[i].text;
		if (lkp < SPRITEFRMWRK_SIZE){
			if (lm & Sprite_LinkMask_Pos){
				x=sprites[lkp].pos.x + (x * sprites[lkp].scale.x);
				y=sprites[lkp].pos.y + (y * sprites[lkp].scale.y);
				z=sprites[lkp].pos.z + (z-.5f);
			}
			if (lm & Sprite_LinkMask_Rotation){
				rot=sprites[lkp].rot + rot;
			}
			if (lm & Sprite_LinkMask_Scale){
				sx=sprites[lkp].scale.x * sx;
				sy=sprites[lkp].scale.y * sy;
			}
			if (lm & Sprite_LinkMask_Tint){
				tn = Gui::tintMultiply(1, tn, sprites[lkp].tint);
			}
		}

		switch(sprites[i].textype) {
			case 0:
				drw.pos.x = x; drw.pos.y = y;
				drw.depth = z;
				drw.angle = rot / SPRITEFRMWRK_CNV_RAD2DEG;
				drw.center.x = hx * sx * tx;
				drw.center.y = hy * sy * ty;
				drw.pos.w = sx * tx;
				drw.pos.h = sy * ty;
				C2D_DrawImage(C2D_SpriteSheetGetImage(sprites[i].sheet, sprites[i].index), &drw, &tn);
				break;
			case 1:
				C2D_DrawText(&ctx, C2D_WithColor, \
				x - (hx * tx * sx), y - (hy * ty * sy),\
				z, sx * SPRITEFRMWRK_TXTW, sy * SPRITEFRMWRK_TXTH, tn.corners[0].color);
				break;
		}
	}
}

void SpriteFrmwrk::clearAll(){
	for (u16 i=0; i<SPRITEFRMWRK_SIZE; i++){
		sprites[i].active=false; sprites[i].shown=false;
		sprites[i].linkParent=65535; sprites[i].linkMask=0;
	}
}
void SpriteFrmwrk::clearRange(u16 first, u16 last){
	if (first >= SPRITEFRMWRK_SIZE) return;
	if (last >= SPRITEFRMWRK_SIZE) return;
	for (u16 i=first; i<=last; i++){
		sprites[i].active=false; sprites[i].shown=false;
		sprites[i].linkParent=65535; sprites[i].linkMask=0;
	}
}
void SpriteFrmwrk::setSprite(u16 index, C2D_SpriteSheet sheet, size_t sheetidx, bool screen){
	if (index >= SPRITEFRMWRK_SIZE || sheetidx >= C2D_SpriteSheetCount(sheet)) return;
	C2D_Image img; C2D_ImageTint inittint;
	C2D_PlainImageTint(&inittint, -1 ,0);
	sprites[index].textype = 0;
	sprites[index].sheet = sheet;
	sprites[index].index = sheetidx;
	sprites[index].screen = screen;
	sprites[index].rot = .0f;
	sprites[index].pos.x = .0f;
	sprites[index].pos.y = .0f;
	sprites[index].pos.z = .5f;
	sprites[index].center.x = .0f;
	sprites[index].center.y = .0f;
	sprites[index].scale.x = 1.f;
	sprites[index].scale.y = 1.f;
	sprites[index].linkParent = 65535;
	sprites[index].linkMask = 0;
	sprites[index].tint = inittint;
	sprintf(sprites[index].name,"%32s","");
	img=C2D_SpriteSheetGetImage(sheet, sheetidx);
	sprites[index].texw = img.subtex->width;
	sprites[index].texh = img.subtex->height;
	sprites[index].active = true;
	sprites[index].shown = true;
}
void SpriteFrmwrk::setSprite(u16 index, const char* text, bool screen){
	if (index >= SPRITEFRMWRK_SIZE) return;
	C2D_TextBufClear(sprites[index].tbuf);
	float w, h; C2D_ImageTint inittint;
	C2D_PlainImageTint(&inittint,-1,1);
	sprites[index].textype = 1;
	sprites[index].screen = screen;
	sprites[index].rot = .0f;
	sprites[index].pos.x = .0f;
	sprites[index].pos.y = .0f;
	sprites[index].pos.z = .5f;
	sprites[index].center.x = .0f;
	sprites[index].center.y = .0f;
	sprites[index].scale.x = 1.f;
	sprites[index].scale.y = 1.f;
	sprites[index].linkParent = -1;
	sprites[index].linkMask = 0;
	sprites[index].tint = inittint;
	sprintf(sprites[index].name,"%s","");
	if (sizeof(text) < SPRITEFRMWRK_TEXTSZ){
		C2D_TextFontParse(&sprites[index].text, systemFont, sprites[index].tbuf, text);
	} else {
		C2D_TextFontParse(&sprites[index].text, systemFont, sprites[index].tbuf, "[String invalid]");
	}
	C2D_TextOptimize(&sprites[index].text);
	C2D_TextGetDimensions(&sprites[index].text, SPRITEFRMWRK_TXTW,SPRITEFRMWRK_TXTH,&w,&h);
	sprites[index].texw = w;
	sprites[index].texh = h;
	sprites[index].active = true;
	sprites[index].shown = true;
}
u16 SpriteFrmwrk::setSprRemote(u16 firstid, C2D_SpriteSheet sheet, size_t sheetidx, bool screen){
	if (firstid >= SPRITEFRMWRK_SIZE || sheetidx >= C2D_SpriteSheetCount(sheet)) return 65535;
	u16 i;
	for (i=firstid; i < SPRITEFRMWRK_SIZE; i++){
		if (!(sprites[i].active))
			break;
	}
	if (i >= SPRITEFRMWRK_SIZE) return 65535;
	setSprite(i,sheet,sheetidx,screen);
	return i;
}
u16 SpriteFrmwrk::setSprRemote(u16 firstid, const char* text, bool screen){
	if (firstid >= SPRITEFRMWRK_SIZE) return 65535;
	u16 i;
	for (i=firstid; i < SPRITEFRMWRK_SIZE; i++){
		if (!(sprites[i].active))
			break;
	}
	if (i >= SPRITEFRMWRK_SIZE) return 65535;
	setSprite(i,text,screen);
	return i;
}
void SpriteFrmwrk::setSprGfx(u16 index, C2D_SpriteSheet sheet, size_t sheetidx){
	if (index >= SPRITEFRMWRK_SIZE || sheetidx >= C2D_SpriteSheetCount(sheet)) return;
	C2D_Image img;
	sprites[index].textype = 0;
	sprites[index].sheet = sheet;
	sprites[index].index = sheetidx;
	img=C2D_SpriteSheetGetImage(sheet, sheetidx);
	sprites[index].texw = img.subtex->width;
	sprites[index].texh = img.subtex->height;
}
void SpriteFrmwrk::setSprTxt(u16 index, const char* text){
	if (index >= SPRITEFRMWRK_SIZE) return;
	float w, h;
	C2D_TextBufClear(sprites[index].tbuf);
	sprintf(sprites[index].name,"%s","");
	if (sizeof(text) < SPRITEFRMWRK_TEXTSZ){
		C2D_TextFontParse(&sprites[index].text, systemFont, sprites[index].tbuf, text);
	} else {
		C2D_TextFontParse(&sprites[index].text, systemFont, sprites[index].tbuf, "[String invalid");
	}
	C2D_TextOptimize(&sprites[index].text);
	C2D_TextGetDimensions(&sprites[index].text, SPRITEFRMWRK_TXTW,SPRITEFRMWRK_TXTH,&w,&h);
	sprites[index].textype = 1;
	sprites[index].texw = w;
	sprites[index].texh = h;
}
void SpriteFrmwrk::setSprScr(u16 index, bool screen){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].screen = screen;
}
void SpriteFrmwrk::setSprOff(u16 index, float x, float y){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].pos.x = x;
	sprites[index].pos.y = y;
}
void SpriteFrmwrk::setSprHome(u16 index, float x, float y){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].center.x = x;
	sprites[index].center.y = y;
}
void SpriteFrmwrk::setSprDepth(u16 index, float z){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].pos.z = z+.5f;
}
void SpriteFrmwrk::setSprRot(u16 index, float r){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].rot = r;
}
void SpriteFrmwrk::setSprScale(u16 index, float sx, float sy){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].scale.x = sx;
	sprites[index].scale.y = sy;
}
void SpriteFrmwrk::setSprTint(u16 index, C2D_ImageTint tint){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].tint = tint;
}
void SpriteFrmwrk::setSprName(u16 index, const char* name){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprintf(sprites[index].name,"%32s",name);
}
void SpriteFrmwrk::setSprLink(u16 index, u16 father, u8 mask){
	if (index >= SPRITEFRMWRK_SIZE) return;
	if (father >= index) return;
	sprites[index].linkParent=father; sprites[index].linkMask=mask;
}
void SpriteFrmwrk::setSprFloat(u16 index, u8 var, float value){
	if (index >= SPRITEFRMWRK_SIZE) return;
	if (var >= 16) return;
	sprites[index].floats[var] = value;
}
void SpriteFrmwrk::setSprInt(u16 index, u8 var, int value){
	if (index >= SPRITEFRMWRK_SIZE) return;
	if (var >= 32) return;
	sprites[index].ints[var] = value;
}
void SpriteFrmwrk::setSprVisible(u16 index, bool show){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].shown = show;
}
void SpriteFrmwrk::addSprOff(u16 index, float x, float y){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].pos.x += x;
	sprites[index].pos.y += y;
}
void SpriteFrmwrk::addSprRot(u16 index, float r){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].rot += r;
}
void SpriteFrmwrk::getSprGfx(u16 index, C2D_SpriteSheet sheet, size_t* sheetidx){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sheet = sprites[index].sheet;
	*sheetidx = sprites[index].index;
}
void SpriteFrmwrk::getSprTxt(u16 index, char* text){
	if (index >= SPRITEFRMWRK_SIZE) return;
	text = (char*)sprites[index].text.buf;
}
void SpriteFrmwrk::getSprTexSize(u16 index, u32* w, u32* h){
	if (index >= SPRITEFRMWRK_SIZE) return;
	*w = sprites[index].texw;
	*h = sprites[index].texh;
}
bool SpriteFrmwrk::getSprScr(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return 0;
	return sprites[index].screen;
}
void SpriteFrmwrk::getSprOff(u16 index, float* x, float* y){
	if (index >= SPRITEFRMWRK_SIZE) return;
	*x = sprites[index].pos.x;
	*y = sprites[index].pos.y;
}
void SpriteFrmwrk::getSprHome(u16 index, float* x, float* y){
	if (index >= SPRITEFRMWRK_SIZE) return;
	*x = sprites[index].center.x;
	*y = sprites[index].center.y;
}
float SpriteFrmwrk::getSprDepth(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return U64_MAX;
	return sprites[index].pos.z;
}
float SpriteFrmwrk::getSprRot(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return U64_MAX;
	return sprites[index].rot;
}
void SpriteFrmwrk::getSprScale(u16 index, float* sx, float* sy){
	if (index >= SPRITEFRMWRK_SIZE) return;
	*sx = sprites[index].scale.x;
	*sy = sprites[index].scale.y;
}
C2D_ImageTint* SpriteFrmwrk::getSprTint(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return NULL;
	return &sprites[index].tint;
}
char* SpriteFrmwrk::getSprName(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return NULL;
	return sprites[index].name;
}
void SpriteFrmwrk::getSprLink(u16 index, u16* father, u8* mask){
	if (index >= SPRITEFRMWRK_SIZE) return;
	*father = sprites[index].linkParent;
	*mask = sprites[index].linkMask;
}
bool SpriteFrmwrk::getSprVisible(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return 0;
	return sprites[index].shown;
}
float SpriteFrmwrk::getSprFloat(u16 index, u8 var){
	if (index >= SPRITEFRMWRK_SIZE) return U64_MAX;
	if (var >= 16) return U64_MAX;
	return sprites[index].floats[var];
}
int SpriteFrmwrk::getSprInt(u16 index, u8 var){
	if (index >= SPRITEFRMWRK_SIZE) return 0x7FFFFFFF;
	if (var >= 32) return 0x7FFFFFFF;
	return sprites[index].ints[var];
}
void SpriteFrmwrk::clearSprite(u16 index){
	if (index >= SPRITEFRMWRK_SIZE) return;
	sprites[index].active=false; sprites[index].shown=false;
	sprites[index].linkParent=65535; sprites[index].linkMask=0;
}