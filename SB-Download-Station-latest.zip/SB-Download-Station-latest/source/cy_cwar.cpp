#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <3ds.h>
#include "sound.hpp"
#include "cy_cwar.hpp"

CY_CWAR_SE sfx[128];
size_t sfx_c;

void CY_CWAR::Free(){
	for(size_t i=0; i<sfx_c; i++){
		sfx[i].snd->Stop();
		if (sfx[i].snd->sound) cwavFree(sfx[i].snd->sound);
		if (sfx[i].snd) linearFree(sfx[i].snd);
	}
}
int CY_CWAR::LoadCYCWAR(const char* fname){
	int err=0; sfx_c=0; u32 cwavo=0; size_t idx,sfxi=0;
	char byte; u16 byte2; u32 byte4;
	std::ifstream csar(fname,std::fstream::binary);
	char* fbuf;
	fbuf=new char[10];
	csar.read(fbuf, 10);
	if (memcmp(fbuf,"CY64CWAR\x03\x00",10)!=0) {err=1; goto end;}
	csar.read((char*)&byte2,2); sfx_c=byte2 & 127;
	csar.read((char*)&byte4,4); cwavo=byte4;
	fbuf=new char[64];
	while(sfxi < sfx_c){
		idx=0; memset(fbuf,0,64);
		while(true){
			csar.read(&byte,1);
			if (!byte) break;
			fbuf[idx++]=byte;
		}
		sprintf(sfx[sfxi].name,"%s",fbuf); sfx[sfxi].fsz=0;
		csar.read((char*)&byte4,4); sfx[sfxi].fsz = byte4;
		csar.read(&byte,1); sfx[sfxi].flg = byte;
		sfxi++;
	}
	csar.seekg(cwavo, csar.beg);
	for (size_t i=0; i<sfx_c; i++){
		sfx[i].snd = new Sound("",1);
		void* cwavbuf=linearAlloc(sfx[i].fsz);
		if(!cwavbuf) svcBreak(USERBREAK_PANIC);
		csar.read((char*)cwavbuf,sfx[i].fsz);
		cwavLoad(sfx[i].snd->sound,cwavbuf,sfx[i].flg>>1);
		sfx[i].snd->isLoaded = sfx[i].snd->sound->loadStatus == CWAV_SUCCESS;
		sfx[i].snd->sound->dataBuffer = cwavbuf;
	}
	end:
	if (fbuf) delete fbuf;
	csar.close();
	return err;
}
size_t CY_CWAR::GetID(const char* name){
	for(size_t i=0; i<sfx_c; i++){
		if(memcmp(name,sfx[i].name,strlen(name))==0) return i;
	}
	return 0xDEAD;
}
Sound* CY_CWAR::GetSfx(const char* name){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) return sfx[idx].snd;
	return NULL;
}
void CY_CWAR::Play(const char* name){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) PlayID(idx);
}
void CY_CWAR::PlayID(size_t idx){
	if(idx >= sfx_c) return;
	if(sfx[idx].flg & 1){sfx[idx].snd->StereoPlay();}else{sfx[idx].snd->Play();}
}
void CY_CWAR::Stop(const char* name){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) StopID(idx);
}
void CY_CWAR::StopID(size_t idx){
	if(idx >= sfx_c) return;
	sfx[idx].snd->Stop();
}
void CY_CWAR::SetVolume(const char* name, float vol){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) SetVolumeWithID(idx,vol);
}
void CY_CWAR::SetVolumeWithID(size_t idx, float vol){
	if(idx >= sfx_c) return;
	sfx[idx].snd->SetVolume(vol);
}
void CY_CWAR::SetPitch(const char* name, float pth){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) SetPitchWithID(idx,pth);
}
void CY_CWAR::SetPitchWithID(size_t idx, float pth){
	if(idx >= sfx_c) return;
	sfx[idx].snd->SetPitch(pth,1);
}
void CY_CWAR::FadeVolume(const char* name, float vol, int frm){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) FadeVolumeWithID(idx,vol,frm);
}
void CY_CWAR::FadeVolumeWithID(size_t idx, float vol, int frm){
	if(idx >= sfx_c) return;
	sfx[idx].snd->SetTargetVolume(vol,frm);
}
void CY_CWAR::FadePitch(const char* name, float pth, int frm){
	size_t idx=GetID(name);
	if (idx!=0xDEAD) FadePitchWithID(idx,pth,frm);
}
void CY_CWAR::FadePitchWithID(size_t idx, float pth, int frm){
	if(idx >= sfx_c) return;
	sfx[idx].snd->SetCreatePitch(pth,frm);
}
void CY_CWAR::Tick(){
	for(size_t i=0; i<sfx_c; i++){
		sfx[i].snd->Tick();
	}
}
