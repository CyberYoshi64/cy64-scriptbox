#include <assert.h>
#include <stdarg.h>
#include <unistd.h>
#include <fstream>
#include <dirent.h>
#include <cmath>
#include "gui.hpp"
#include "main.hpp"
#include "keyboard.h"
#include "errtbl.hpp"
#include "cia.hpp"
#include "cy_cwar.hpp"
#include "mathlogic.hpp"
#include "thread.h"
#include "dialog.hpp"

C3D_RenderTarget *top, *bottom;

C2D_SpriteSheet gfx_scrbg;
C2D_SpriteSheet gfx_button;
C2D_SpriteSheet gfx_common;
C2D_SpriteSheet gfx_cy64;
C2D_SpriteSheet gfx_ghud;
C2D_SpriteSheet meta_img;
C2D_SpriteSheet gfx_appdlg;
C2D_SpriteSheet gfx_menu;

char errorstr[2048];
int errorcode=0;
int touchpt, touchpx, touchpy;
int touchot, touchox, touchoy;
int maincnt; float millisec;
std::string keyboardIn;
char stringtochar_buf[8192];
C2D_TextBuf sizeBuf;
C2D_Font systemFont;
float fontwdhDiff = 1.0f;
float fonthgtDiff = 1.0f;
C2D_ImageTint guitmptint;
u16 spriteRemote;

extern bool wifiConnected;
extern bool batBelow0c;
extern bool batBelow1c;
extern bool batCharge;
extern u64 topNotificationTimer;
extern u8 topNotificationSfx;
extern u32 topNotificationColor;
extern std::string topNotificationText;
extern std::string top_screen_title;
extern bool changeTopTitle;
extern bool disableTopTitle;
extern bool disableTopTxtBG;
extern bool exiting;
extern int pageid;
extern u64 topTextID;
extern u8 CFGLang; 
extern u8 consoleRegion;


u8 dlgResult;

bool fadein = true;
bool fadeout;
u8 fadealpha;
u8 fadecolor;

void Gui::clearTextBufs(void) {
	C2D_TextBufClear(sizeBuf);
}
Result Gui::init(void) {
	u32 transFlags=	GX_TRANSFER_FLIP_VERT(false)|
					GX_TRANSFER_OUT_TILED(false)|
					GX_TRANSFER_RAW_COPY(false)|
					GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8)|
					GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB8)|
					GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_NO);
	
	top = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
	C3D_RenderTargetClear(top, C3D_CLEAR_ALL, 0, 0);
	C3D_RenderTargetSetOutput(top, GFX_TOP, GFX_LEFT, transFlags);
	
	bottom = C3D_RenderTargetCreate(240, 320, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
	C3D_RenderTargetClear(bottom, C3D_CLEAR_ALL, 0, 0);
	C3D_RenderTargetSetOutput(bottom, GFX_BOTTOM, GFX_LEFT, transFlags);
	
	C3D_SetScissor(GPU_SCISSOR_INVERT, 5,5,394,234);

	sizeBuf		= C2D_TextBufNew(8192);
	gfx_scrbg	= C2D_SpriteSheetLoad("rom:/gfx/scrbg.t3x");
	gfx_common	= C2D_SpriteSheetLoad("rom:/gfx/common.t3x");
	gfx_button	= C2D_SpriteSheetLoad("rom:/gfx/button.t3x");
	gfx_cy64	= C2D_SpriteSheetLoad("rom:/gfx/cy64.t3x");
	gfx_ghud	= C2D_SpriteSheetLoad("rom:/gfx/ghud.t3x");
	gfx_appdlg	= C2D_SpriteSheetLoad("rom:/gfx/appdlg.t3x");
	gfx_menu	= C2D_SpriteSheetLoad("rom:/gfx/menugfx.t3x");
	setSheetTexFilter(gfx_appdlg, GPU_LINEAR, GPU_LINEAR);
	setSheetTexFilter(gfx_button, GPU_LINEAR, GPU_LINEAR);
	setSheetTexFilter(gfx_common, GPU_LINEAR, GPU_LINEAR);
	setSheetTexFilter(gfx_ghud, GPU_LINEAR, GPU_LINEAR);
	setSheetTexFilter(gfx_menu, GPU_LINEAR, GPU_LINEAR);
	C3D_TexSetFilter(C2D_SpriteSheetGetImage(gfx_ghud, ghud_bg_idx).tex, GPU_NEAREST, GPU_NEAREST);

	//systemFont	= C2D_FontLoadSystem((CFG_Region)consoleRegion);
	systemFont	= C2D_FontLoad("rom:/font/0.bcfnt");
	return 0;
}
void Gui::exit(void) {
	if (gfx_scrbg)	C2D_SpriteSheetFree(gfx_scrbg);
	if (gfx_common)	C2D_SpriteSheetFree(gfx_common);
	if (gfx_cy64)	C2D_SpriteSheetFree(gfx_cy64);
	if (gfx_button)	C2D_SpriteSheetFree(gfx_button);
	if (gfx_ghud)	C2D_SpriteSheetFree(gfx_ghud);
	if (gfx_menu)	C2D_SpriteSheetFree(gfx_menu);
	if (systemFont)	C2D_FontFree(systemFont);
	if (meta_img)	C2D_SpriteSheetFree(meta_img);
	if (sizeBuf)	C2D_TextBufDelete(sizeBuf);
}

void Gui::setSheetTexFilter(C2D_SpriteSheet sheet, GPU_TEXTURE_FILTER_PARAM magfil, GPU_TEXTURE_FILTER_PARAM minfil){
	for (size_t i=0; i<C2D_SpriteSheetCount(sheet); i++){
		C3D_TexSetFilter(C2D_SpriteSheetGetImage(sheet, i).tex, magfil, minfil);
	}
}

void set_screen(C3D_RenderTarget* screen) {
	C2D_SceneBegin(screen);
}

void Gui::sprite(C2D_SpriteSheet* sheet, int key, int x, int y, float sx, float sy) {
	if (key == sprites_res_null_idx) {
		return;
	} else { // standard case
		C2D_DrawImageAt(C2D_SpriteSheetGetImage(*sheet, key), x, y, 0.5f, nullptr, sx, sy);
	}
}
void Gui::spriteTinted(C2D_SpriteSheet* sheet, int key, int x, int y, float sx, float sy, u32 color, float tintstrength) {
	C2D_ImageTint tint;
	C2D_PlainImageTint(&tint, color, tintstrength);
	if (key == sprites_res_null_idx) {
		return;
	} else { // standard case
		C2D_DrawImageAt(C2D_SpriteSheetGetImage(*sheet, key), x, y, 0.5f, &tint, sx, sy);
	}
}
void Gui::spriteWithTint(C2D_SpriteSheet* sheet, int key, int x, int y, float sx, float sy, C2D_ImageTint tint) {
	if (key == sprites_res_null_idx) {
		return;
	} else { // standard case
		C2D_DrawImageAt(C2D_SpriteSheetGetImage(*sheet, key), x, y, 0.5f, &tint, sx, sy);
	}
}
void Gui::gcls(C3D_RenderTarget * screen, u32 color){
	C2D_TargetClear(screen,color);
}

void Draw_FontSclCnv(float ix, float iy, float *ox, float *oy){
	//float x = ix * fontwdhDiff, y = iy * fonthgtDiff;
	*ox = ix; *oy = iy;
}

void Draw_Text(float x, float y, float size, u32 color, const char *text) {
	C2D_Text c2d_text;
	float w=size, h=size; //Draw_FontSclCnv(size, size, &w, &h);
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	C2D_DrawText(&c2d_text, C2D_WithColor | C2D_AlignLeft, x, y, 0.5f, w, h, color);
}

void DrawStrBox(float x, float y, float size, u32 color, const char *text, float width, float maxwidth = 1) {
	C2D_Text c2d_text;
	float w, h; Draw_FontSclCnv(size, size, &w, &h);
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	C2D_DrawText(&c2d_text, C2D_WithColor, x, y, 0.5f, clamp(w*(width/Draw_GetTextWidth(size, text)),0.001, w * maxwidth), h, color);
}

void Draw_Text_Center(float x, float y, float size, u32 color, const char *text) {
	C2D_Text c2d_text;
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	C2D_DrawText(&c2d_text, C2D_WithColor | C2D_AlignCenter, x, y, 0.5f, size, size, color);
}

void DrawStrBoxC(float x, float y, float size, u32 color, const char *text, float width, float maxwidth = 1) {
	C2D_Text c2d_text;
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	float temp=clamp(size*(width/Draw_GetTextWidth(size, text)),0.001, size * maxwidth);
	C2D_DrawText(&c2d_text, C2D_WithColor | C2D_AlignCenter, x, y, 0.5f, temp, size, color);
}

void DrawStrBoxCC(float x, float y, float size, u32 color, const char *text, float width, float height) {
	C2D_Text c2d_text;
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	float tempx=clamp(width / Draw_GetTextWidth(size, text), 0.0001f, 1.f) * size;
	float tempy=clamp(height / Draw_GetTextHeight(size, text), 0.0001f, 1.f) * size;
	C2D_DrawText(&c2d_text, C2D_WithColor | C2D_AlignCenter, x, y - Draw_GetTextHeight(tempy, text) / 2, 0.5f, tempx, tempy, color);
}

void Draw_Text_Right(float x, float y, float size, u32 color, const char *text) {
	C2D_Text c2d_text;
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextOptimize(&c2d_text);
	C2D_DrawText(&c2d_text, C2D_WithColor | C2D_AlignRight, x, y, 0.5f, size, size, color);
}

void Draw_GetTextSize(float size, float *width, float *height, const char *text) {
	C2D_Text c2d_text;
	C2D_TextFontParse(&c2d_text, systemFont, sizeBuf, text);
	C2D_TextGetDimensions(&c2d_text, size, size, width, height);
}
float Draw_GetTextWidth(float size, const char *text) {
	float width;
	Draw_GetTextSize(size, &width, NULL, text);
	return width;
}
float Draw_GetTextHeight(float size, const char *text) {
	float height;
	Draw_GetTextSize(size, NULL, &height, text);
	return height;
}
bool Draw_Rect(float x, float y, float w, float h, u32 color) {
	return C2D_DrawRectSolid(x, y, 0.5f, w, h, color);
}

void TintShine(C2D_ImageTint* tint, float timer, u32 color, float strength){
	u8 r=color>>24,g=color>>16,b=color>>8;
	C2D_SetImageTint(tint, C2D_TopLeft, C2D_Color32(r,g,b,255), strength * clamp(1.0f-(_1ddist(timer,16.0f)/16.0f),0.0f,1.0f));
	
	C2D_SetImageTint(tint, C2D_TopRight, C2D_Color32(r,g,b,255), strength * clamp(1.0f-(_1ddist(timer,20.0f)/16.0f),0.0f,1.0f));
	C2D_SetImageTint(tint, C2D_BotLeft, C2D_Color32(r,g,b,255), strength * clamp(1.0f-(_1ddist(timer,22.0f)/16.0f),0.0f,1.0f));
	
	C2D_SetImageTint(tint, C2D_BotRight, C2D_Color32(r,g,b,255), strength * clamp(1.0f-(_1ddist(timer,26.0f)/16.0f),0.0f,1.0f));
}

void TintShineFull(C2D_ImageTint* tint, float timer, u32 color, u32 back, float strength, float tintstr){
	u8 fr=(color>>24)&255,fg=(color>>16)&255,fb=(color>>8)&255,fa=color&255;
	u8 br=(back>>24)&255,bg=(back>>16)&255,bb=(back>>8)&255,ba=back&255;
	float fbs=strength * clamp(1.0f-(_1ddist(timer,16.0f)/16.0f),0.0f,1.0f);
	C2D_SetImageTint(tint, C2D_TopLeft, C2D_Color32(mixNum(br,fr,fbs), mixNum(bg,fg,fbs), mixNum(bb,fb,fbs), mixNum(ba,fa,fbs)), tintstr);
	fbs=strength * clamp(1.0f-(_1ddist(timer,20.0f)/16.0f),0.0f,1.0f);
	C2D_SetImageTint(tint, C2D_TopRight, C2D_Color32(mixNum(br,fr,fbs), mixNum(bg,fg,fbs), mixNum(bb,fb,fbs), mixNum(ba,fa,fbs)), tintstr);
	fbs=strength * clamp(1.0f-(_1ddist(timer,22.0f)/16.0f),0.0f,1.0f);
	C2D_SetImageTint(tint, C2D_BotLeft, C2D_Color32(mixNum(br,fr,fbs), mixNum(bg,fg,fbs), mixNum(bb,fb,fbs), mixNum(ba,fa,fbs)), tintstr);
	fbs=strength * clamp(1.0f-(_1ddist(timer,26.0f)/16.0f),0.0f,1.0f);
	C2D_SetImageTint(tint, C2D_BotRight, C2D_Color32(mixNum(br,fr,fbs), mixNum(bg,fg,fbs), mixNum(bb,fb,fbs), mixNum(ba,fa,fbs)), tintstr);
}

C2D_ImageTint Gui::tintMultiply(bool walpha, C2D_ImageTint src, C2D_ImageTint mul){
	C2D_ImageTint out;
	float sr,sg,sb,sa,sbl;
	float mr,mg,mb,ma=1,mbl=1;
	for(u8 i=0; i<4; i++){
		sr=((src.corners[i].color >> 8) & 0xFF)/255.f;
		sg=((src.corners[i].color >> 16) & 0xFF)/255.f;
		sb=((src.corners[i].color >> 24) & 0xFF)/255.f;
		sa=((src.corners[i].color) & 0xFF)/255.f;
		sbl=src.corners[i].blend;
		mr=((mul.corners[i].color >> 8) & 0xFF)/255.f;
		mg=((mul.corners[i].color >> 16) & 0xFF)/255.f;
		mb=((mul.corners[i].color >> 24) & 0xFF)/255.f;
		if (walpha){
			ma=((mul.corners[i].color) & 0xFF)/255.f;
			mbl=mul.corners[i].blend;
		}
		out.corners[i].blend = sbl*mbl;
		out.corners[i].color = C2D_Color32f(sr*mr,sg*mg,sb*mb,sa*ma);
	}
	return out;
}

void Gui::_3dsAppletEvent(){}

void Gui::ScreenLogic(u32 hDown, u32 hHeld, touchPosition touch){
	maincnt++;
	millisec += 1.0f/60.0f;
	touchox = touchpx;
	touchoy = touchpy;
	touchot = touchpt;
	touchpx = touch.px;
	touchpy = touch.py;
	
	if (hDown & KEY_X)
		SpriteFrmwrk::clearAll();
	
	if (hDown & KEY_B){
		u32 texw, texh; C2D_ImageTint sptn;
		u16 fatherSp=SpriteFrmwrk::setSprRemote(0, gfx_menu, menugfx_prj_bg_idx, 1);
		SpriteFrmwrk::setSprHome(fatherSp, .5f, .5f);
		SpriteFrmwrk::setSprOff(fatherSp, 160, 72);
		spriteRemote=SpriteFrmwrk::setSprRemote(0, gfx_menu, menugfx_prj_missingimg_idx, 1);
		SpriteFrmwrk::setSprHome(spriteRemote, .5f, .5f);
		SpriteFrmwrk::setSprOff(spriteRemote, -96, 0);
		SpriteFrmwrk::setSprLink(spriteRemote, fatherSp, -1);
		spriteRemote=SpriteFrmwrk::setSprRemote(0, "SKKBAUI v0.3.8 — darn it", 1);
		C2D_PlainImageTint(&sptn, 0xFF204000, 1);
		SpriteFrmwrk::setSprTint(spriteRemote, sptn);
		SpriteFrmwrk::setSprHome(spriteRemote, 0, 1);
		SpriteFrmwrk::setSprOff(spriteRemote, -64, -16);
		SpriteFrmwrk::getSprTexSize(spriteRemote, &texw, &texh);
		SpriteFrmwrk::setSprScale(spriteRemote, clamp(172.f/texw, 0.001f, 1.f), 1);
		SpriteFrmwrk::setSprLink(spriteRemote, fatherSp, 23);
		spriteRemote=SpriteFrmwrk::setSprRemote(0, "CyberYoshi64", 1);
		C2D_PlainImageTint(&sptn, 0xA0000000, 1);
		SpriteFrmwrk::setSprTint(spriteRemote, sptn);
		SpriteFrmwrk::setSprHome(spriteRemote, 0, .9f);
		SpriteFrmwrk::setSprOff(spriteRemote, -64, 0);
		SpriteFrmwrk::getSprTexSize(spriteRemote, &texw, &texh);
		SpriteFrmwrk::setSprScale(spriteRemote, clamp(144.f/texw, 0.001f, .675f), .675f);
		SpriteFrmwrk::setSprLink(spriteRemote, fatherSp, 23);
	}
	SpriteFrmwrk::setSprScale(0, 1+sin(millisec*2)*.125f, 1+sin(millisec*2)*.125f);
	SpriteFrmwrk::setSprRot(0, sin(millisec)*900.f);
	
	if (hDown & KEY_ZR){
		Dialog::Clear();
		Dialog::MainWGiven("Do you want to crash your system?\n\nThis crash throws an error code.");
		Dialog::UseAButtonWGiven("CRASH!");
		Dialog::UseBButtonWGiven("No, please.");
		Dialog::PrepareDisplay();
		dlgResult=Dialog::Show();
		if (dlgResult == 1){errfInit(); ERRF_ThrowResult(0xFFFFFFFF); errfExit();}
	}
	if (hDown & KEY_ZL){
		Dialog::Clear();
		Dialog::MainWGiven("Do you want to crash your system?\n\nThis crash throws a debug message.");
		Dialog::UseAButtonWGiven("CRASH!");
		Dialog::UseBButtonWGiven("No, please.");
		Dialog::PrepareDisplay();
		dlgResult=Dialog::Show();
		if (dlgResult == 1){APP_ThrowError(ERR_SRC_GUI,__func__,__LINE__,"User-generated exception");}
	}
	if (hDown & KEY_A){
		Dialog::Clear();
		Dialog::MainWGiven("This is a test dialog.\n\nPress \uE000 or touch the \"Okay\" button to close it.\nPress \uE001 to exit this application.");
		Dialog::UseAButtonWGiven("Okay");
		Dialog::UseBButtonWGiven("Cancel");
		Dialog::PrepareDisplay();
		dlgResult=Dialog::Show();
		if (dlgResult == 1){
			Dialog::Clear();
			Dialog::MainWGiven("This particular dialog is testing line breaks from long texts. Now I have no idea how to actually do it, lmao.");
			Dialog::UseAButtonWGiven("button only (\uE001 not available)");
			Dialog::PrepareDisplay();
			Dialog::Show();
			Dialog::Clear();
			Dialog::MainWGiven("This box allows 7 lines. Considering how likely it is to fill these lines, I think it's enough to put any detail in for any language. Although I don't know if I can do anything to even fill it. Ok, one more line, I hope it ends soon. Wait, I got past? What is this?");
			Dialog::UseBButtonWGiven("Close");
			Dialog::PrepareDisplay();
			Dialog::Show();
			Dialog::Clear();
			Dialog::WaitForBool(&batCharge, true);
			Dialog::MainWGiven("Please insert the AC adapter.\n\nProceeding with a low battery level is not allowed.");
			Dialog::UseBButtonWGiven("Close");
			Dialog::PrepareDisplay();
			dlgResult=Dialog::Show();
			if (dlgResult==0){
				Dialog::Clear();
				Dialog::MainWGiven("Download aborted.\n\nSome files may not have been downloaded, which may cause the project to fail booting.");
				Dialog::UseAButtonWGiven("Okay");
				Dialog::PrepareDisplay();
				Dialog::Show();

			}
		} else {
			Dialog::Clear();
			Dialog::MainWGiven("Do you want to exit SmileBASIC Download Station?\n\n(Any current downloads will be aborted.)");
			Dialog::UseAButtonWGiven("Yes");
			Dialog::UseBButtonWGiven("No");
			Dialog::PrepareDisplay();
			dlgResult=Dialog::Show();
			if (dlgResult == 1) exiting=true;
		}
	}
	if (hDown & KEY_X){
		topNotificationTimer = 180;
		topNotificationColor = 0x00CCCCFF;
		topNotificationText = "Some dummy notification with a long text. TBH I don't know lol.";
		topNotificationSfx = SCRTOPNOTIF_SFX_MENU;
	}
	
	if (hDown & KEY_Y) {
		topNotificationTimer = 300;
		topNotificationColor = 0xFF4000FF;
		topNotificationText = "The download menu is not ready in this build.";
		topNotificationSfx = SCRTOPNOTIF_SFX_ERROR;
	}

	if (hDown & KEY_START){
		exiting=true;
	}
}
