/*  This file is part of Checkpoint
>	Copyright (C) 2017 Bernardo Giordano
>
>   This program is free software: you can redistribute it and/or modify
>   it under the terms of the GNU General Public License as published by
>   the Free Software Foundation, either version 3 of the License, or
>   (at your option) any later version.
>
>   This program is distributed in the hope that it will be useful,
>   but WITHOUT ANY WARRANTY; without even the implied warranty of
>   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>   GNU General Public License for more details.
>
>   You should have received a copy of the GNU General Public License
>   along with this program.  If not, see <http://www.gnu.org/licenses/>.
>   See LICENSE for information.
*/

#include <3ds.h>
#include <vector>
#include "thread.h"

static std::vector<Thread> threads;

size_t createThread(ThreadFunc entrypoint) {
	s32 prio = 0;
	svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
	Thread thread = threadCreate((ThreadFunc)entrypoint, NULL, 4096, prio-1, -2, true);
	threads.push_back(thread);
	return threads.size()-1;
}

Thread getThread(size_t idx){
	if (idx >= threads.size()) return NULL;
	return threads.at(idx);
}

void destroyThreads(void) {
	for (u32 i = 0; i < threads.size(); i++) {
		threadJoin(threads[i], U64_MAX);
		//if (threads[i]) threadFree(threads[i]);
		threads[i]=NULL;
	}
}

size_t countThreads(void) {
	return threads.size();
}
