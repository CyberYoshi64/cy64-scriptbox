#include "common.hpp"
#include "main.hpp"
#include "keyboard.h"
#include "cy_cwar.hpp"
#include "thread.h"
#include <3ds.h>
#include <dirent.h>
#include <unistd.h>
#include "dialog.hpp"

extern float fontwdhDiff;
extern float fonthgtDiff;
u8 batteryLevel;
u8 soundSliderLvl;
bool wifiConnected;
u32 wifiConnectedVal;
u8 wifiStrength;
bool headSetUsed;
u8 mcureg0F;
char tmpstr[4096];
std::string top_screen_title = "";
bool changeTopTitle = true;
bool disableTopTitle;
bool disableTopTxtBG;
bool wifiStrengthLow;
bool batBelow0;
bool batBelow1;
bool batBelow0c;
bool batBelow1c;
bool batCharge;
bool batChargeS;
bool batChargeE;
bool dspfirmfoundF;
u64 topTextID = 1;
std::string hot_potato_toptitle = "";
float topTitleAnimTime = 1.0f;
float topTextBGAnimTime = 1.0f;
float topNotifAnimTime = 0.0f;
u64 topNotificationTimer = 0;
u32 topNotificationColor = 0;
u8 topNotificationSfx = 0;
std::string topNotificationText = "";
u8 topNotif_red = 0;
u8 topNotif_grn = 0;
u8 topNotif_blu = 0;
u8 topNotif_alp = 0;
u64 topNotifTimer = 0;
u16 homeRejectedTimer = 0;
float homeRejectedOpacity = 0.0f;
std::string hot_potato_topnotif = "";
float fadea; u8 fader, fadeg, fadeb;
C2D_ImageTint shineTint;
float shineTimer=0.0f;

void deviceMkEvent(){
	if (batBelow0 && !batCharge){
		topNotificationTimer = 300;
		topNotificationColor = 0xFFA000FF;
		topNotificationText = "Warning! The battery is below 10%!";
		topNotificationSfx = SCRTOPNOTIF_SFX_WARNING;
	}
	if (batBelow1 && !batCharge){
		topNotificationTimer = 600;
		topNotificationColor = 0xFF4000FF;
		topNotificationText = "Please charge your console now.";
		topNotificationSfx = SCRTOPNOTIF_SFX_ERROR;
	}
	if (batChargeS){
		topNotificationTimer = 180;
		topNotificationColor = 0x4060FFC0;
		topNotificationText = "Charging battery... "+std::to_string(batteryLevel)+"%";
		topNotificationSfx = SCRTOPNOTIF_SFX_MENU;
	}
	if (batChargeE && (batteryLevel < 100)){
		topNotificationTimer = 300;
		topNotificationColor = 0xFF8040FF;
		topNotificationText = "The charging cable was unexpectedly unplugged.";
		topNotificationSfx = SCRTOPNOTIF_SFX_WARNING;
	}
	if (wifiStrengthLow){
		topNotificationTimer = 300;
		topNotificationColor = 0xFF8000FF;
		topNotificationText = "Wi-Fi strength is weak. Please get closer to the access point.";
		topNotificationSfx = SCRTOPNOTIF_SFX_WARNING;
	}
	if (!dspfirmfound && !dspfirmfoundF) {
		topNotificationTimer = 900;
		topNotificationColor = 0xFF0000FF;
		topNotificationText = "The sound output has been disabled.";
		dspfirmfoundF = true;
	}
}

void drawTextInBodyWithID(u64 id){
	switch (id){
		case 0:
			sprintf(tmpstr, \
			"Battery voltage: %d\n" \
			"Sound slider: %d\n" \
			"Wifi Connected? %d\n"\
			"Strength: %d\n"\
			"Headset plugged in? %d\n"\
			"Charging!?: %s",\
			batteryLevel, soundSliderLvl, wifiConnected, wifiStrength, headSetUsed, batCharge ? "true" : "false");
			DrawStrBoxCC(200, 121, FONT_SIZE_12, C2D_Color32f(1,1,1,topTextBGAnimTime), tmpstr, 360, 136);
			break;
		case 1:
			DrawStrBoxCC(200, 121, FONT_SIZE_12, C2D_Color32f(1,1,1,topTextBGAnimTime), LngpackStr(LNGTXT_MAIN_MENU_TXT, CFGLang), 360, 136);
			break;
		default:
			sprintf(tmpstr, "Warning!\n\nAn invalid ID was specified:\n%016llx", topTextID);
			DrawStrBoxCC(200, 121, FONT_SIZE_14, C2D_Color32f(1,0.5f,0,topTextBGAnimTime), tmpstr, 360, 136);
			break;
	}
}

void topNotificationPlaySfx(){
	switch(topNotificationSfx){
		case SCRTOPNOTIF_SFX_ERROR: CY_CWAR::Play("COMMON_ACTION_ERR"); break;
		case SCRTOPNOTIF_SFX_WARNING: CY_CWAR::Play("COMMON_ACTION_WARN"); break;
		case SCRTOPNOTIF_SFX_MENU: CY_CWAR::Play("COMMON_ACTION_MENU"); break;
		case SCRTOPNOTIF_SFX_WRONG: CY_CWAR::Play("COMMON_ACTION_WRONG"); break;
	}
}

void TopScr(){
	Gui::sprite(&gfx_scrbg, scrbg_top_idx, 0, 0, 1, 1);
	if (topNotifAnimTime < 0.001f){
		if (topNotificationText != ""){
			topNotifTimer = topNotificationTimer - 1;
			hot_potato_topnotif = topNotificationText;
			topNotif_red = (topNotificationColor >> 24) & 255;
			topNotif_grn = (topNotificationColor >> 16) & 255;
			topNotif_blu = (topNotificationColor >>  8) & 255;
			topNotif_alp = (topNotificationColor >>  0) & 255;
			topNotificationTimer= 0;
			topNotificationText = "";
			topNotificationPlaySfx();
			topNotificationSfx  = 0;
		}
	} else if (topNotifTimer != 0) {
		topNotifTimer--;
	}
	
	if (changeTopTitle && topTitleAnimTime < 0.001f){
		hot_potato_toptitle=top_screen_title;
		CY_CWAR::Play("COMMON_ACTION_MOVE");
		changeTopTitle=false;
	}
	
	if (topTitleAnimTime > 0.0009f){
		Gui::sprite(&gfx_common,common_ic_div_l_idx, 200.0f - topTitleAnimTime * 200.0f, 56.0f - topTitleAnimTime * 8.0f, topTitleAnimTime, topTitleAnimTime);
		DrawStrBoxC(200, 32.0f - topTitleAnimTime * 8.0f, FONT_SIZE_18, C2D_Color32f(1,1,1,topTitleAnimTime), hot_potato_toptitle.c_str(), 360, 1);
	}
	
	if (topTextBGAnimTime > 0.005f){
		Gui::spriteTinted(&gfx_common,common_ic_textbody_idx, 24, 60, 1, 1, C2D_Color32f(1,1,1,topTextBGAnimTime),0.0f);
		//drawTextInBodyWithID(topTextID);
	}
	
	SpriteFrmwrk::render(SPRITEFRMWRK_SCR_TOP);

	if (topNotifAnimTime > 0.0009f){
		Gui::spriteTinted(&gfx_ghud,ghud_notif_bg_idx, 0, 200, 1, 1, C2D_Color32(topNotif_red, topNotif_grn, topNotif_blu, topNotifAnimTime * topNotif_alp), 1);
		DrawStrBox(8, 224.0f - topNotifAnimTime * 8.0f, 0.5f, C2D_Color32f(1,1,1,topNotifAnimTime), hot_potato_topnotif.c_str(), 320, 1);
	}

	topTitleAnimTime=(topTitleAnimTime * 2.0f + (float)(!changeTopTitle && !disableTopTitle)) / 3.0f;
	switch(!!topNotificationTimer){
		case 0: topNotifAnimTime=(topNotifAnimTime * 5.0f + (float)(!!topNotifTimer)) / 6.0f; break;
		case 1: topNotifAnimTime=topNotifAnimTime * 0.5f; break;
	}
	topTextBGAnimTime=(topTextBGAnimTime * 2.0f + (float)(!disableTopTxtBG)) / 3.0f;
	
	Draw_Text(362,18,0.8f,C2D_Color32f(1,1,1,homeRejectedOpacity),"");
	Draw_Text(360,16,1.0f,C2D_Color32f(1,0,0,homeRejectedOpacity),"／");
	if (homeRejectedTimer > 120) homeRejectedOpacity=((homeRejectedOpacity*7.0f)+1.0f)/8.0f;
	if (homeRejectedTimer < 60) homeRejectedOpacity=homeRejectedOpacity*0.825f;
	if(homeRejectedTimer) homeRejectedTimer--;
	if(aptCheckHomePressRejected()){homeRejectedTimer=180;}
	
	sprintf(tmpstr,"CPU: %6.2f%%", C3D_GetProcessingTime()*6.0f); Draw_Text(0,36,0.35f,-1,tmpstr);
	sprintf(tmpstr,"GPU: %6.2f%%", C3D_GetDrawingTime()*6.0f); Draw_Text(0,48,0.35f,-1,tmpstr);
	sprintf(tmpstr,"CmdBuf: %6.2f%%", C3D_GetCmdBufUsage()*100.0f); Draw_Text(0,60,0.35f,-1,tmpstr);

	DrawStrBox(100, 32, 0.7f, -1, 
	"\ue000\ue001\ue002\ue003\ue004\ue005\ue006\ue007\ue008\ue009\ue00a\ue00b\ue00c\ue00d\ue00e\ue00f\n"
	"\ue010\ue011\ue012\ue013\ue014\ue015\ue016\ue017\ue018\ue019\ue01a\ue01b\ue01c\ue01d\ue01e\ue01f\n"
	"\ue020\ue021\ue022\ue023\ue024\ue025\ue026\ue027\ue028\ue029\ue02a\ue02b\ue02c\ue02d\ue02e\ue02f\n"
	"\ue030\ue031\ue032\ue033\ue034\ue035\ue036\ue037\ue038\ue039\ue03a\ue03b\ue03c\ue03d\ue03e\ue03f\n"
	"\ue040\ue041\ue042\ue043\ue044\ue045\ue046\ue047\ue048\ue049\ue04a\ue04b\ue04c\ue04d\ue04e\ue04f\n"
	"\ue050\ue051\ue052\ue053\ue054\ue055\ue056\ue057\ue099\ue09a\ue09b\ue09c\ue09d\ue09e\ue09f\ue0a0\n"
	"\ue0a1\ue0a2\ue300\ue301\ue302\ue303\ue304\ue305\ue306\ue307\ue308\ue309\ue30a\ue30b\ue30c\ue30d\n"
	"\ue30e\ue30f\ue310\ue311\ue312\ue313\ue314\ue315\ue316\ue317\ue318\ue319\ue31a\ue31b", 300, 1.0f);

	Gui::sprite(&gfx_ghud,ghud_bg_idx,0,0,10,1);
	Gui::sprite(&gfx_ghud,ghud_wifi_disabled_idx + wifiConnected +(wifiConnected * wifiStrength),2,2,1,1);
	Gui::spriteTinted(&gfx_ghud,ghud_connectstat_bg_idx,26,1,1,1,C2D_Color32(64+(!wifiConnected*64),160-(!wifiConnected*32),255-(!wifiConnected*127),255),1.0f);
	sprintf(tmpstr,"%s",wifiConnected?"Internet":"Disabled");
	DrawStrBoxC(78,2,0.5f,-1,tmpstr,320,1); // 3DS HUD replica. Commented out, as it doesn't really fit...
}

void BotScr(){
	Gui::sprite(&gfx_scrbg,scrbg_bottom_idx, 0, 0, 1, 1);
	Gui::sprite(&gfx_menu,menugfx_prj_bg_idx, 32,32,1,1);
	Gui::sprite(&gfx_menu,menugfx_prj_missingimg_idx, 40,48,1,1);
	DrawStrBox(96, 40, 0.65f, 0xFF204000, "SKKBAUI v0.3.8 — oh god damnit", 176, 1);
	DrawStrBox(96, 62, 0.45f, 0xA0000000, "CyberYoshi64", 176, 1);
	Gui::spriteTinted(&gfx_menu,menugfx_prj_flag_bg_idx, 96,80,1,1, 0xFF1078FF, 1);
	Gui::sprite(&gfx_menu,menugfx_prj_flag_sizelvl2_idx, 100,84,1,1);
	Gui::spriteTinted(&gfx_menu,menugfx_prj_flag_bg_idx, 126,80,1,1, 0xFF609000, 1);
	Gui::sprite(&gfx_menu,menugfx_prj_flag_ui_idx, 130,84,1,1);
	Gui::spriteTinted(&gfx_menu,menugfx_prj_flag_bg_idx, 156,80,1,1, 0xFF20A070, 1);
	Gui::sprite(&gfx_menu,menugfx_prj_flag_beta_idx, 160,84,1,1);
	Gui::spriteTinted(&gfx_menu,menugfx_prj_flag_bg_idx, 186,80,1,1, 0xFF2040C0, 1);
	Gui::sprite(&gfx_menu,menugfx_prj_flag_cancel_idx, 190,84,1,1);
	Gui::sprite(&gfx_menu,menugfx_prj_ok_idx, 240,68,1,1);
	Gui::spriteWithTint(&gfx_menu,menugfx_prj_bg_idx, 32,32,1,1,shineTint);
	SpriteFrmwrk::render(SPRITEFRMWRK_SCR_BOTTOM);
}

void Display::Render(){
	fadea=1.0f;
	MCUHWC_ReadRegister(0xf,&mcureg0F,1);
	batChargeS = ((mcureg0F >> 4) & 1) && !batCharge;
	batChargeE = !((mcureg0F >> 4) & 1) && batCharge;
	batCharge = (mcureg0F >> 4) & 1;
	MCUHWC_GetBatteryLevel(&batteryLevel);
	MCUHWC_GetSoundSliderLevel(&soundSliderLvl);
	ACU_GetStatus(&wifiConnectedVal);
	wifiConnected=(bool)(wifiConnectedVal==3);
	wifiStrengthLow = (osGetWifiStrength() < 2 && wifiStrength >= 3);
	wifiStrength=osGetWifiStrength();
	headSetUsed=osIsHeadsetConnected();
	batBelow0 = ((batteryLevel <= 10) && !batBelow0c);
	batBelow1 = ((batteryLevel <= 5) && !batBelow1c);
	batBelow0c = batteryLevel <= 10;
	batBelow1c = batteryLevel <= 5;
	
	TintShineFull(&shineTint, shineTimer, -1, -256, 1, .5f);
	shineTimer += 1.f;
	if (shineTimer>64) shineTimer -= 64.0f;

	deviceMkEvent();
	
	C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
	Gui::clearTextBufs();
	
	// top screen
	set_screen(top);
	TopScr();
	
	if (exiting){
		Draw_Rect(0,0,400,240,C2D_Color32(fader,fadeg,fadeb,fadea * 255.0f));
	}
	
	// bottom screen
	set_screen(bottom);
	BotScr();
	
	if (Dialog::IsDialogShown()) {
		Dialog::Display();
	}

	if (exiting){
		Draw_Rect(0,0,320,240,C2D_Color32(fader,fadeg,fadeb,fadea * 255.0f));
	}
	
	C2D_Flush();
	C3D_FrameEnd(0);
	if (errorcode){
		showError(AppErrTbl(errorcode, CFGLang),errorcode);
		errorcode = 0;
	}
	fadea=(fadea * 3.0f + ((exiting) * 1.0f)) / 4.0f;
}
