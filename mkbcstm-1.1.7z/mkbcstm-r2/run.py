#!/usr/bin/env python
import os
from sys import argv
from glob import glob

def iff(x,i,o):
	if x: return i
	else: return o

def supressOutputStr(): return iff(os.sep=="/"," &>> out.log",">>out.log")

def strpad(num,dgt,pad):
	nums=str(num)
	while len(nums)<dgt:
		nums=pad+nums
	return nums

def execCnv2DSP(file):
	global loop
	if file=="": return ""
	outf=file.rsplit(".",1)[0]+".dsp"
	# If on Linux, touch files manually. F**k you Wine for not doing it yourself.
	if (os.sep=="/"):
		os.system("touch "+outf+" "+file.rsplit(".",1)[0].split("/",1)[1]+".txt")
	cmd="wine "*(os.sep=="/")+"DSPADPCM -E "+file+" "+outf
	if loop: cmd=cmd+" -l"+str(loopbeg)+"-"+str(loopend)
	cmd=cmd+supressOutputStr()
	os.system(cmd)
	return outf

def execMkBcstm(file,flist):
	if os.sep=="/": os.system("touch "+file)
	os.system("wine "*(os.sep=="/")+"revb --build-bcstm "+file+flist+supressOutputStr())

def fatalerr(id):
	if id==1 or id==2 or id==5 or id==6:
		print(\
"""
Unable to generate DSP files from all found .WAV files.

Did you make sure all wave files in {}
are exported as signed 16bit PCM?
""".format(argv[2]))
	if id==3:
		print(\
"""
Unable to generate the output BCSTM.

Did you make sure all wave files in {}
have the same amount of samples?
""".format(argv[2]))
	if id==128: print(\
'''
No applicable wavesound files were found.

Are you in the correct folder? (Or are the WAV files in
a seperate folder you didn't specify in argument 2?)
If you specified just a folder, try putting a slash after the name.
''')
	if id==257: print('Cannot find "revb.exe" in working directory')
	if id==258: print('Cannot find "DSPADPCM.exe" in working directory')
	if id==259: print('Cannot find "dsptool.dll" in working directory')
	if id==260: print('Cannot find "soundfile.dll" in working directory')
	exit()

def usage(a):
	print("""
Usage: {} {} OutFile FileMask [loopBeg loopEnd]

OutFile   — Output file name (with extension, always outputs CTR streams)
FileMask  — Folder and/or file prefix to save in
            (Note that this tool requires the channels to already be stripped
            into Signed 16bit WAV files. Don't worry, Audacity has the
            "Export multiple..." option that saves the day lol)
            The channel sounds must be sorted in alphabetical order (or
            numeric with pre-padding zeroes) and a ".wav" file extension

Must be specified
as a pair. If you  \\ loopBeg – Loop point start
want to omit them, / loopEnd – Loop point end
put \"\" for each instead
""".format(iff(os.sep=="/","python",""),argv[0]))
	if a==1: print("Bad number of arguments")
	if a==2: print("loopBeg and loopEnd must be specified as a pair")
	exit()

regdsp=""; mfldsp=""; files=[]; loop=False; loopbeg=0; loopend=0
if len(glob("out.log")): os.system("rm out.log")

if not len(glob("revb.exe")): fatalerr(257)
if not len(glob("DSPADPCM.exe")): fatalerr(258)
if not len(glob("dsptool.dll")): fatalerr(259)
if not len(glob("soundfile.dll")): fatalerr(260)

if len(argv)<3 or len(argv)>6: usage(1)
if len(argv)==4: usage(1)
if len(argv)>4:
	if bool(len(argv[3])) ^ bool(len(argv[4])): usage(2)
	if argv[3]+argv[4]!="":
		loop=True
		loopbeg=int(argv[3])
		loopend=int(argv[4])

files=sorted(glob(argv[2]+"*.wav")+glob(argv[2]+"*.WAV"))
idxstrlen=len(str(len(files)+1))
icmdc=strpad(len(files)+1, idxstrlen, " ")

if not len(files): fatalerr(128)

print("Please don't interrupt this with Ctrl+C, this may corrupt stuff")

for i in range(len(files)):
	print("({}/{}) Converting {} ..." .format(strpad(i+1, idxstrlen, " "), icmdc, files[i]))

	execCnv2DSP(files[i])
	
listdsp=sorted(glob(argv[2]+"*.dsp"))
for j in listdsp:
	if j.endswith("_F.dsp"): mfldsp += " "+j
	else: regdsp += " "+j

i=len(files)+1
print("({}/{}) Building {} ...".format(strpad(i, idxstrlen, " "), icmdc, argv[1]))
execMkBcstm(argv[1], regdsp)

if len(glob(argv[2]+"*.dsp")) < len(files): fatalerr(1)
if len(glob("*.txt")) < len(files): fatalerr(2)
if not len(glob(argv[1])): fatalerr(3)

os.system("rm "+argv[2]+"*.dsp *.txt")
