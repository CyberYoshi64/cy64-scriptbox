### Demon's Multi-Channel BCSTM tool, adapted for Linux

Requirements:
- Linux: Wine along with the `wine-mono` package installed
- Windows: .NET 4.0 (Windows 10/11 have that preinstalled)

Syntax: `./run.py OutFile FileMask [loopBeg loopEnd]`

- `OutFile` - File name to save as (include .bcstm yourself)
- `FileMask` - Folder and/or prefix of WAV files to include (see Example 1)
- `loopBeg` & `loopEnd` - Loop points in samples (1s @ 44kHz → sample 44000)

These WAV files are ordered alphanumerically, said files also must be 16bit; using the Export feature in Audacity; other encodings aren't supported.

If the looppoints were not specified or both are 2 quotes each (""), will be treated as no loop.

**Please do not try interrupting the code with Ctrl+C, as that will skip steps instead of cancelling.**

#### Examples

__Example 1__

`./run.py STRM_LOL_N.bcstm normal/ 131000 1980000`

The WAV files are located in the "normal" folder and the loop points are set to ~3s and 45s in the music.


__Example 2__

`python run.py sound1.bcstm music-ch "" ""`

The WAV files are in the current directory starting with "music-ch" and no loop points were defined
